This file contains Matlab code to implement MWCBI and MWCBII in practice, and replicate the simulation results in Hounyo and Lin (2025), "Wild Bootstrap Inference with Multiway Clustering and Serially Correlated Time Effects"

To implement MWCBI and MWCBII in practice, open this zip-folder, call Matlab down to folder "MWCBs", and you will be able to use MWCBI and MWCBII. 

In folder "MWCBs", main_example provides an example regarding how to implement MWCBI and MWCBII. 

To replicate the simulation results, call Matlab down to folder "Simulation", and run main.m.

If you have any questions please contact Jiahao Lin on jlin28@albany.edu

Jiahao Lin
May 31 2025