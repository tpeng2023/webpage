function res = kernel(dist,bandwidth)
%
xx = 1 - abs(dist/(bandwidth));

if xx>=0
    res = xx;
else
    res = 0;
end
%
%res = exp(-(dist/bandwidth)^2);
