function [tstat,ll,qq00] = reg_tstat_serial_II(yy,xx,load_mat,S11,S22,qq)

NN = size(S11,1);
TT = size(S22,1);
KK = size(xx,2);
BigX = xx;
BigY = yy;
NT = NN * TT;
KK= size(BigX,2);

scale11 = NN*(NT-1)/(NN-1)/(NT-KK);
scale22 = TT*(NT-1)/(TT-1)/(NT-KK);
scale33 = NN*TT*(NT-1)/(NN*TT-1)/(NT-KK);

bhat_ols = inv(BigX'*BigX)*(BigX'*BigY); % OLS bhat
Uhat_ols = reshape(BigY-BigX*bhat_ols,[TT,NN]); % T by N
xx = reshape(BigX,[TT,NN,KK]);
sscore = xx .* Uhat_ols;
SSR = sum(sum(Uhat_ols.*Uhat_ols));
sig_u2 = SSR/(NT);
V_X = BigX'*BigX/NT;
V_X_inv = inv(V_X);

%% OLS standard error: default in Stata S.E.
est_Var_ols = sig_u2*V_X_inv/NT;
SE_ols = sqrt(diag(est_Var_ols));

%% White's standard error: 'robust' Stata

sscore_reshape = reshape(sscore,[NT,KK]);
V_W = sscore_reshape' * sscore_reshape/NT;
est_Var_W = V_X_inv*V_W*V_X_inv/(NT);
SE_W = sqrt(diag(est_Var_W));

%% Clustered standard error
% Clustering by individual
V_CX = squeeze(sum(sscore,1))' *  squeeze(sum(sscore,1)) / NT;
est_Var_CX = V_X_inv*V_CX*V_X_inv/(NT);
SE_CX = sqrt(diag(est_Var_CX));

% Clustering by time
V_CT = squeeze(sum(sscore,2))' *  squeeze(sum(sscore,2)) / NT;
est_Var_CT = V_X_inv*V_CT*V_X_inv/(NT);
SE_CT = sqrt(diag(est_Var_CT));

V_CI = V_W;

est_Var_CGM_scale = V_X_inv*(scale22*V_CT+scale11*V_CX-scale33*V_CI)*V_X_inv/(NT);
est_Var_CGM = V_X_inv*(V_CT+V_CX-V_CI)*V_X_inv/(NT);
SE_CGM_scale = sqrt(diag(est_Var_CGM_scale));
SE_CGM = sqrt(diag(est_Var_CGM));

est_Var_DHG = V_X_inv*(V_CT+V_CX)*V_X_inv/(NT);
SE_DHG = sqrt(diag(est_Var_DHG));


%%
if nargin == 5
    ss = squeeze(mean(sscore,2));
    nomin = 0; denomin = 0;
    for kk = 1:KK
        S_1 = ss(:,kk);

        rrho_hat1 = (S_1(1:end-1)' * S_1(1:end-1))^(-1) * S_1(1:end-1)' * S_1(2:end);
        nomin = nomin + rrho_hat1^2/(1-rrho_hat1)^4;
        denomin = denomin + (1-rrho_hat1^2)^2/(1-rrho_hat1)^4;
    end
    ll = 1.8171*(nomin/denomin)^(1/3)*TT^(1/3);
    ll = round(ll);
    %qq00 = (1/2)^((nomin/denomin)^(-1/5)*2*TT^(-1/5));  
    qq00 = exp(-(nomin/denomin)^(-1/3)*TT^(-1/3));
elseif nargin ~= 5
    qq00 = qq;
end




%% CHS, CV variances, and bias-correct CV
%b = ll/TT;
ss11 = squeeze(sum(sscore,2));

V_CV = (V_CT + V_CX);
V_CV_boot = (V_CT + V_CX); % for bootstrap variance, the only difference is that kernel function = 1
V_CHS = (V_CT + V_CX - V_W);
V_CHS_boot = (V_CT + V_CX - V_W);
%V_BCCV = V_CX + (1-b+1/3*b^2)^(-1) * V_CT;

for hh = 1:TT
    sscore_TT = ss11(hh+1:TT,:);
    sscore_TThh = ss11(1:TT-hh,:);
    GG_hat = sscore_TT' * sscore_TThh;

    sscore_TTNN = reshape(sscore(hh+1:TT,:,:),[(TT-hh)*NN,KK]);
    sscore_TThhNN = reshape(sscore(1:TT-hh,:,:),[(TT-hh)*NN,KK]);
    HH_hat = sscore_TThhNN' * sscore_TTNN;

    V_CV = V_CV + 1/NT*qq00^(hh)*(GG_hat+GG_hat');
    V_CV_boot = V_CV_boot + 1/NT*(GG_hat+GG_hat');
    V_CHS = V_CHS + 1/NT*qq00^(hh)*(GG_hat+GG_hat'-HH_hat-HH_hat');
    V_CHS_boot = V_CHS_boot + 1/NT*(GG_hat+GG_hat'-HH_hat-HH_hat');
    %V_BCCV = V_BCCV + (1-b+1/3*b^2)^(-1) *1/NT*qq00^hh*(GG_hat+GG_hat');
end



est_Var_CHS = V_X_inv*V_CHS*V_X_inv/(NT);
SE_CHS = sqrt(diag(est_Var_CHS));

est_Var_CHS_boot = V_X_inv*V_CHS_boot*V_X_inv/(NT);
SE_CHS_boot = sqrt(diag(est_Var_CHS_boot));

est_Var_CV = V_X_inv*V_CV*V_X_inv/(NT);
SE_CV = sqrt(diag(est_Var_CV));

est_Var_CV_boot = V_X_inv*V_CV_boot*V_X_inv/(NT);
SE_CV_boot = sqrt(diag(est_Var_CV_boot));

%est_Var_BCCV = V_X_inv*V_BCCV*V_X_inv/(NT);
%SE_BCCV = sqrt(diag(est_Var_BCCV));

%% bias-correct CHS

%V_BCCHS = (1-b+1/3*b^2)^(-1) * V_CHS;
%est_Var_BCCHS = V_X_inv*V_BCCHS*V_X_inv/(NT);
%SE_BCCHS = sqrt(diag(est_Var_BCCHS));


%%

SE_our = [SE_ols,SE_W,SE_CX,SE_CT,SE_CGM,SE_CGM_scale,SE_DHG,SE_CHS,SE_CHS_boot,SE_CV,SE_CV_boot,SE_CV_boot,SE_CV_boot]';  % 13 elements
tstat = [(bhat_ols(end)-load_mat(end))./SE_our(:,end);(bhat_ols(end)-load_mat(end))];
for ii = 1:size(SE_our,1)
    pos_de(ii,1) = isreal(SE_our(ii,:));
end




