function [beta,residual] = reg_coeff(Y,X,type,beta_null)
%%

KK = size(X,2);
if type == 'u' % unrestricted
    beta = (X'*X)\(X'*Y);
else
    if type == 'r' % restricted
        beta = [inv(X(:,1:end-1)'*X(:,1:end-1))*(X(:,1:end-1)'*(Y-beta_null*X(:,end)));beta_null];
    end
end

residual = Y - X*beta;
