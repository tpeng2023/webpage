% ll=load_ff(DDset_keep, ff4fac11);

function [coeff,residual,leverage] = load_ff(yy,xx,type,beta_null)
%%

% vol estimate

KK = size(yy,2); % no of columns/ funds
std_an = nan(1,KK); 
DD_demean = [];
residual = nan(size(yy));
ffbench = xx;
residual = nan(size(yy));
coeff = [];


for kk = 1:KK
    
    ret11 = yy(:,kk);
    ind0 = (isnan(ret11) == 0); % 1 if not NaN

    yy = ret11(ind0); % payoff for fund kk (no NaN)
    xx = [ffbench(ind0,:)]; % factors for fund kk
    
    if type == 'u'
        beta = (xx'*xx)\(xx'*yy);
        inv_xx =  eye(size(xx,2))/(xx'*xx);
        leverage = sum((xx.*(xx*inv_xx))')';
    else 
        if type == 'r'
            beta = [inv(xx(:,1:end-1)'*xx(:,1:end-1))*(xx(:,1:end-1)'*(yy-beta_null*xx(:,end)));beta_null];
            inv_xx =  eye(size(xx(:,1:end-1),2))/(xx(:,1:end-1)'*xx(:,1:end-1));
            leverage = sum((xx(:,1:end-1).*(xx(:,1:end-1)*inv_xx))')';
        else 
            beta = nan(size(ffbench,2),1);
            leverage = nan(size(xx,1),1);
        end
    end
    
    yhat = yy - xx*beta;
    sig2e = (yhat'*yhat)/(sum(ind0) - size(xx,2)); % mean square residuals

    
    std_an(kk) = sqrt(sig2e)*sqrt(12); % mean saquare residuals for one year
    
    adj11 = nan(length(ind0),1);
    adj11(ind0==1) = (yy - beta(1)); % demean payoff for fund kk
    
    DD_demean = [DD_demean, adj11];
    residual(ind0,kk) = yhat;
    coeff = [coeff,beta];

     
end

