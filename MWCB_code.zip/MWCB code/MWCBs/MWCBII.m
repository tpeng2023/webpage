function[p_value,bbeta_hat] = MWCBII(yy,xx,bbeta_null)
% Let T and N be the total number of time periods and individuals, respectively.
% Input "yy" is T*N, "xx" is T*N*K data, 
% bbeta_null is based on the null hypothesis, by default it is [0;0;...;0].
%%

xx_ori = xx;
[TT,NN,KK] = size(xx);
yy = reshape(yy,[NN*TT,1]);
xx = reshape(xx_ori,[NN*TT,KK]);

if nargin == 3
    bbeta0 = bbeta_null;
else
    bbeta0 = zeros(KK,1);
end

bbeta_hat = reg_coeff(yy,xx,'u',bbeta0);
p_value = [];
for kk = 1:KK

    xx = reshape(xx_ori,[NN*TT,KK]);
    xx(:,KK+1) = xx(:,kk);
    xx(:,kk) = [];

    S11 = kron(eye(NN),ones(1,TT)); % indicator matrix
    S22 = kron(ones(1,NN),eye(TT));
    SII = eye(NN*TT);


    QQ = 9999; % number of bootstrap replications
    GG = size(S11,1);
    HH = size(S22,1);
    II = size(SII,1);

    %%



    [load_mat, resi_mat] = reg_coeff(yy,xx,'r',bbeta0(kk));
    %[statori,~,qq00] = reg_tstat_serial(yy,xx,bbeta0,S11,S22);
    [statori,ll,qq00,SE] = reg_tstat_serial(yy,xx,bbeta0(kk),S11,S22);
    pp = (SE(4)/TT)/(SE(4)/TT+SE(3)/NN);

    xxinv = inv(xx'*xx);
    RR = zeros(1,KK);
    RR(end) = 1;
    xx_xxinv = xx*xxinv;
    Mx = eye(size(xx,1)) - xx_xxinv*xx';

    %% bootstrap

    eetaTT00 = 2*binornd(1,0.5,1,QQ)-1;
    for tt = 1:HH-1
        bb = 2*binornd(1,(1+qq00)/2,1,QQ)-1;
        eetaTT00(tt+1,:) = eetaTT00(tt,:).*bb;
    end

    eetaNN00 = 2*binornd(1,0.5,GG,QQ)-1;
    aa00 = binornd(1,pp,II,QQ);
    eetaTT = (S22' * eetaTT00);
    eetaNN =  (S11' * eetaNN00);
    aa = SII' * (aa00);
    eeta = aa .* eetaTT + (1-aa) .* eetaNN;


    nomin = (resi_mat.*(xx_xxinv*RR'))'*eeta;

    %JJ = (diag(S22*(xxRR.*resi_mat)) - S22*(xxRR.*xx)*xxinv*(S22*(resi_mat.*xx))')*eeta00;
    JJ_ori = (xx_xxinv*RR'.*Mx.*resi_mat')*eeta;
    JJ11 = S11*JJ_ori;
    JJ22 = S22*JJ_ori;
    JJII = JJ_ori;


    V_CT_boot = 0; V_CI_boot = 0;
    for hh = 1:ll-1
        V_CT_boot = V_CT_boot + 2 * sum(JJ22(hh+1:HH,:).*JJ22(1:HH-hh,:));
        ind11 = []; ind22 = [];
        for gg = 1:GG
            ind11 = [ind11 (gg-1)*HH+hh+1:gg*HH];
            ind22 = [ind22 (gg-1)*HH+1:gg*HH-hh];
        end
        V_CI_boot = V_CI_boot + 2 * sum(JJII(ind11,:).*JJII(ind22,:));
    end


    denomin = sum(JJ11.*JJ11) + sum(JJ22.*JJ22) - sum(JJII.*JJII) + V_CT_boot - V_CI_boot;


    stat_boot = nomin./sqrt(denomin); % OLS bhat
    tstat_boot_all = stat_boot(:,imag(stat_boot)==0);


    %%
    QQ00 = length(tstat_boot_all);
    p_equal(:,1) = 2 * min(1/QQ00 * sum(tstat_boot_all<statori,2),1/QQ00 * sum(tstat_boot_all>statori,2));
    p_sym(:,1) = 1/QQ00 * sum(abs(tstat_boot_all)>abs(statori),2);

    p_value(kk,1) = p_equal(8,end);


end

end







