rng(3798)
clear;
clc;

bbeta0 = [];
KK = 10;
bbeta0(1,1,1:KK) = [ones(5,1); zeros(5,1)]; 


NN = 25; % number of individuals
TT = 50; % number of time periods
waalphha = 1; % cross-sectional correlation weight for error term
wggamma = 1; % serial correlation weight for error term
weepsilon = 1; % idiocyncratic weight
rrho = 0.50; % level of serial dependence

aalpha = randn(1,NN,KK); % individual effect
eepsilon = randn(TT,NN,KK); % idiocyncratic term iid over i and t

ggamma = randn(1,1,KK); % time effect
for tt = 1:TT+100
    ggamma(tt+1,1,:) =  rrho * ggamma(tt,1,:) + random('Normal',0,sqrt(1-rrho^2),1,1,KK);
end
ggamma = ggamma(end-TT+1:end,:,:);
% Before obtaining ggamma, we allow the AR(1) process to progress for 100 time periods.
xx = waalphha * aalpha + wggamma * ggamma + weepsilon * eepsilon;

% the same procedure to generate error term uu:
aalpha = randn(1,NN); % individual effect
eepsilon = randn(TT,NN);

ggamma = randn(1,1); % time effect
for tt = 1:TT+100
    ggamma = [ggamma; rrho * ggamma(end,:) + random('Normal',0,sqrt(1-rrho^2))];
end
ggamma = ggamma(end-TT+1:end,:);
uu = waalphha * aalpha + wggamma * ggamma + weepsilon * eepsilon;

% intercept term
xx(:,:,1) = ones(TT,NN,1);
yy = sum(bbeta0 .* xx,3) + uu;


%% % suppose we want to make inference on bbeta0

% null hypothesis bbeta0=0 not true for bbeta0(1:5), but true for bbeta0(6:10)
[p_value1,bbeta_hat] = MWCBI(yy,xx); 
p_value2 = MWCBII(yy,xx); 



% If null hypothesis is not all zero, suppose we know tue value of bbeta0
p_value1_true = MWCBI(yy,xx,bbeta0); 
p_value2_true = MWCBII(yy,xx,bbeta0); 

%%
T = table(bbeta_hat,p_value1,p_value2,p_value1_true,p_value2_true,...
    'VariableNames',{'beta hat','p_value1','p_value2','p_value1 H0 true','p_value2 H0 true'});
display(T)