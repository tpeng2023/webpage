function[test_equal,test_sym,p_equal,p_sym,p_left] = boot_menzel_resi(yy,xx,sgnl,bbeta0,QQ,S11,S22)
% the restricted residual version of the menzel's bootstrap



GG = size(S11,1);
HH = size(S22,1);
KK = size(xx,2);
xxx = reshape(xx,[HH,GG,KK]);
yyy = reshape(yy,[HH,GG,1]);
%%



[load_mat, resi_mat] = reg_coeff(yy,xx,'r',bbeta0(end));
[statori,ll] = reg_tstat_serial(yy,xx,bbeta0,S11,S22);
load_mat = reshape(load_mat,[1,1,KK]);
resi_mat = reshape(resi_mat,[HH,GG]);

%% bootstrap

tstat_boot_all = [];

for qq = 1:QQ % QQ is the total number of iterations

    GG_boot = datasample(1:GG,GG);
    HH_boot = datasample(1:HH,HH);

    resi_GG = mean(resi_mat,1);
    resi_HH = mean(resi_mat,2);
    resi_rest = resi_mat - resi_GG - resi_HH;


    resi_boot_GG = resi_GG(GG_boot);
    resi_boot_HH = resi_HH(HH_boot);
    resi_boot_rest = resi_rest(HH_boot,GG_boot);


    xx_boot = xx;
    resi_boot = resi_boot_GG + resi_boot_HH + resi_boot_rest;
    yy_boot = sum(xxx.*reshape(load_mat,[1,1,KK]),3) + resi_boot;


    BigX_boot = reshape(xx_boot,[HH*GG,KK]);
    BigY_boot = reshape(yy_boot,[HH*GG,1]);

    stat_boot = reg_tstat_serial(BigY_boot,BigX_boot,load_mat,S11,S22,ll); % OLS bhat

    tstat_boot_all = [tstat_boot_all, stat_boot];
end

%%

p_equal = 2 * min(1/QQ * sum(tstat_boot_all<statori,2),1/QQ * sum(tstat_boot_all>statori,2));
p_sym = 1/QQ * sum(abs(tstat_boot_all)>abs(statori),2);

test_equal = p_equal <= sgnl;
test_sym = p_sym <= sgnl;

p_left = mean(tstat_boot_all<=statori,2);



