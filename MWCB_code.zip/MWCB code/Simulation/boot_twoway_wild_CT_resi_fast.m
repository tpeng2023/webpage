function[test_equal,test_sym,p_equal,p_sym] = boot_twoway_wild_CT_resi_fast(yy,xx,sgnl,bbeta0,QQ,S11,S22,SII)

%QQ = 399;

GG = size(S11,1);
HH = size(S22,1);

%%



[load_mat, resi_mat] = reg_coeff(yy,xx,'r',bbeta0(end));
[statori,ll] = reg_tstat_serial(yy,xx,bbeta0,S11,S22);

xxinv = inv(xx'*xx);
RR = zeros(1,length(bbeta0));
RR(end) = 1;
xx_xxinv = xx*xxinv;
Mx = eye(size(xx,1)) - xx_xxinv*xx';
%% bootstrap


eeta00 = 2*random('Binomial',1,1/2,HH,QQ)-1;

S_boot = S22;

nomin = (S_boot*(resi_mat.*(xx_xxinv*RR')))'*eeta00;

%JJ = (diag(S22*(xxRR.*resi_mat)) - S22*(xxRR.*xx)*xxinv*(S22*(resi_mat.*xx))')*eeta00;
JJ_ori = (xx_xxinv*RR'.*Mx.*resi_mat')*S_boot'*eeta00;
JJ11 = S11*JJ_ori;
JJ22 = S22*JJ_ori;
JJII = JJ_ori;

V_CT_boot = 0; V_CI_boot = 0;
for hh = 1:ll-1
    V_CT_boot = V_CT_boot + 2 *kernel(hh,ll) *  sum(JJ22(hh+1:HH,:).*JJ22(1:HH-hh,:));
    ind11 = []; ind22 = [];
    for gg = 1:GG
        ind11 = [ind11 (gg-1)*HH+hh+1:gg*HH];
        ind22 = [ind22 (gg-1)*HH+1:gg*HH-hh];
    end
    V_CI_boot = V_CI_boot + 2 *kernel(hh,ll) *  sum(JJII(ind11,:).*JJII(ind22,:));
end
    


denomin = sum(JJ11.*JJ11) + sum(JJ22.*JJ22) - sum(JJII.*JJII) + V_CT_boot - V_CI_boot;

denomin_CV= sum(JJ11.*JJ11) + sum(JJ22.*JJ22) + V_CT_boot;
denomin_CGM= sum(JJ11.*JJ11) + sum(JJ22.*JJ22) - sum(JJII.*JJII);


stat_boot = nomin./sqrt(denomin); % OLS bhat
tstat_boot_all = stat_boot(:,imag(stat_boot)==0); 

stat_boot_CV = nomin./sqrt(denomin_CV);
tstat_boot_CV = stat_boot_CV(:,imag(stat_boot_CV)==0); 

stat_boot_CGM = nomin./sqrt(denomin_CGM);
tstat_boot_CGM = stat_boot_CGM(:,imag(stat_boot_CGM)==0); 

%%
QQ00 = length(tstat_boot_all);
p_equal(:,1) = 2 * min(1/QQ00 * sum(tstat_boot_all<statori,2),1/QQ00 * sum(tstat_boot_all>statori,2));
p_sym(:,1) = 1/QQ00 * sum(abs(tstat_boot_all)>abs(statori),2);

QQ22 = length(tstat_boot_CV);
p_equal(:,2) = 2 * min(1/QQ22 * sum(tstat_boot_CV<statori,2),1/QQ22 * sum(tstat_boot_CV>statori,2));
p_sym(:,2) = 1/QQ22 * sum(abs(tstat_boot_CV)>abs(statori),2);

QQ33 = length(tstat_boot_CGM);
p_equal(:,3) = 2 * min(1/QQ33 * sum(tstat_boot_CGM<statori,2),1/QQ33 * sum(tstat_boot_CGM>statori,2));
p_sym(:,3) = 1/QQ33 * sum(abs(tstat_boot_CGM)>abs(statori),2);


test_equal = p_equal(:) <= sgnl;
test_sym = p_sym(:) <= sgnl;


%p_left = mean(tstat_boot_all<=statori,2);



