bbeta0 = [];
KK = 10; % number of regressors
bbeta0(1,1,1:KK) = ones(KK,1);

sgnl = 0.05; % predetermined significance level
QQ = 1999; % number of bootstrap replications in each method
BBB = 10000; % number of simulations, one may use a small number to obtain tentative result quickly
rrho_choice = 0:0.1:0.9;


test = [];
for ii = 1:length(rrho_choice)
    % choose parameter values, in the example, we vary rrho. One can vary other
    % parameter to check the relative effect.
    NN = 25; % number of individuals
    TT = 50; % number of time periods
    waalphha = 1; % cross-sectional correlation weight for error term
    wggamma = 1; % serial correlation weight for error term
    weepsilon = 1;
    % choose (0,0,1) for iid data
    rrho = rrho_choice(ii); % varying level of serial dependence
    tic;
    %%
    test_sum = 0;
    parfor bbb = 1:BBB
% DGP 
        aalpha = randn(1,NN,KK); % individual effect
        eepsilon = randn(TT,NN,KK); 
        
        ggamma = randn(1,1,KK); % time effect
        for tt = 1:TT+100
            ggamma(tt+1,1,:) =  rrho * ggamma(tt,1,:) + random('Normal',0,sqrt(1-rrho^2),1,1,KK);
        end
        ggamma = ggamma(end-TT+1:end,:,:); 
        % Before acquiring ggamma, we allow the AR(1) process to progress for 100 time periods.
        xx = waalphha * aalpha + wggamma * ggamma + weepsilon * eepsilon;  
       
        % the same procedure to generate error term uu:
        aalpha = randn(1,NN); % individual effect
        eepsilon = randn(TT,NN); 
        
        ggamma = randn(1,1); % time effect
        for tt = 1:TT+100
            ggamma = [ggamma; rrho * ggamma(end,:) + random('Normal',0,sqrt(1-rrho^2))];
        end
        ggamma = ggamma(end-TT+1:end,:); 
        % Before obtaining ggamma, we allow the AR(1) process to progress for 100 time periods.
        uu = waalphha * aalpha + wggamma * ggamma + weepsilon * eepsilon;

%{ 
% nonlinear DGP
aalpha = randn(1,NN,KK); % individual effect
        eepsilon = randn(TT,NN,KK); 
        
        ggamma = randn(1,1,KK); % time effect
        for tt = 1:TT+100
            ggamma(tt+1,1,:) =  rrho * ggamma(tt,1,:) + random('Normal',0,sqrt(1-rrho^2),1,1,KK);
        end
        ggamma = ggamma(end-TT+1:end,:,:); 
        % Before acquiring ggamma, we allow the AR(1) process to progress for 100 time periods.
        xxpp = normcdf(waalphha * aalpha + wggamma * ggamma + weepsilon * eepsilon);  
        xx = log(xxpp./(1-xxpp));
       

        % the same procedure to generate error term uu:
        aalpha = randn(1,NN); % individual effect
        eepsilon = randn(TT,NN); 
        
        ggamma = randn(1,1); % time effect
        for tt = 1:TT+100
            ggamma = [ggamma; rrho * ggamma(end,:) + random('Normal',0,sqrt(1-rrho^2))];
        end
        ggamma = ggamma(end-TT+1:end,:); 
        % Before acquiring ggamma, we allow the AR(1) process to progress for 100 time periods.
        uupp = normcdf(waalphha * aalpha + wggamma * ggamma + weepsilon * eepsilon);  
        uu = log(uupp./(1-uupp));
%}

        % include constant term
        xx(:,:,1) = ones(TT,NN,1);
        
        yy = sum(bbeta0 .* xx,3) + uu;

        yy = reshape(yy,[NN*TT,1]);
        xx = reshape(xx,[NN*TT,KK]);

        S11 = kron(eye(NN),ones(1,TT)); % indicator matrix
        S22 = kron(ones(1,NN),eye(TT));  
        SII = eye(NN*TT);

        %% test (make inference on bbeta0(10))

        test_result = zeros(14*3,25);

        statori = reg_tstat_serial_II(yy,xx,bbeta0,S11,S22);
        test_result(1:14,end-1) = abs(statori) >= 1.96;

        [statori,~,~,SE] = reg_tstat_serial(yy,xx,bbeta0,S11,S22);
        test_result(1:14,end) = abs(statori) >= 1.96;       

        [test11,test22] = boot_twoway_wild_CI_resi_fast(yy,xx,sgnl,bbeta0,QQ,S11,S22,SII);
        test_result(:,1) = test11;
        test_result(:,2) = test22;

        [test11,test22] = boot_twoway_wild_CT_resi_fast(yy,xx,sgnl,bbeta0,QQ,S11,S22,SII);
        test_result(:,3) = test11;
        test_result(:,4) = test22;

        [test11,test22] = boot_twoway_wild_CX_resi_fast(yy,xx,sgnl,bbeta0,QQ,S11,S22,SII);
        test_result(:,5) = test11;
        test_result(:,6) = test22;

        [test11,test22] = boot_twoway_wild_MWCB_resi_fast(yy,xx,sgnl,bbeta0,QQ,S11,S22,SII);
        test_result(:,7) = test11;
        test_result(:,8) = test22;

        pp_adp = (SE(4)/TT)/(SE(4)/TT+SE(3)/NN);
        [test11,test22] = boot_twoway_wild_MWCBII_resi_fast(yy,xx,sgnl,bbeta0,QQ,S11,S22,SII,pp_adp);
        test_result(:,9) = test11;
        test_result(:,10) = test22;

        %{
        [test11,test22] = boot_pigenhole_resi(yy,xx,sgnl,bbeta0,QQ,S11,S22);
        test_result(1:14,11) = test11;
        test_result(1:14,12) = test22;

        [test11,test22] = boot_menzel_resi(yy,xx,sgnl,bbeta0,QQ,S11,S22);
        test_result(1:14,13) = test11;
        test_result(1:14,14) = test22;
        %}

        test_sum = test_sum + test_result/BBB;      
    end

    test(:,:,ii) = test_sum;
    ii
    toc
    %save('time rrho main')
end





%% draw figure

%figure
clf
ww = 0; % ww=0 for for equal-tail p value, =1 for symmetric p value
hold on
ii = 8; 
plot(squeeze(test(ii,end,:)),'m-','DisplayName','$\widehat{V}_{CHS}$ CLT','LineWidth',3,'MarkerSize',5)
plot(squeeze(test(ii,end-1,:)),'m--','DisplayName','$\widehat{V}_{CHS,V}$ CLT','LineWidth',3,'MarkerSize',5)
plot(squeeze(test(ii,5+ww,:)),'b:','DisplayName','WCR$_{G}$','LineWidth',3,'MarkerSize',5)
plot(squeeze(test(ii,3+ww,:)),'b--s','DisplayName','WCR$_{H}$','LineWidth',3,'MarkerSize',5)
plot(squeeze(test(ii,7+ww,:)),'k-o','DisplayName','MWCB$_{I}$','LineWidth',3,'MarkerSize',5)
plot(squeeze(test(ii,9+ww,:)),'r-','DisplayName','MWCB$_{II}$','LineWidth',3,'MarkerSize',5)
%plot(squeeze(test(ii,11+ww,:)),'r:o','DisplayName','PGH-R','LineWidth',3,'MarkerSize',5)
%plot(squeeze(test(ii,13+ww,:)),'r--','DisplayName','M-R','LineWidth',3,'MarkerSize',5)
xticks(1:length(rrho_choice))
xticklabels(rrho_choice)
xlim([1,10])
ylim([0,0.25])
yline(0.05,'k-.','DisplayName','Significance Level')
xlabel('\it\rho')
ylabel('Rejection Frequency')
fontsize(gca,40,"pixels")
hold off
legend('location','northwest','FontSize',30,'Interpreter','latex')
legend('boxoff')
